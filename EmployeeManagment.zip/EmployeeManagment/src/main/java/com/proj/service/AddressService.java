package com.proj.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proj.model.Address;
import com.proj.repository.AddressRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AddressService {
	@Autowired
    AddressRepository addressRepo;

    public List<Address> getAll() {
        return addressRepo.findAll();
    }

    public Address getById(Long id) {
        return addressRepo.findById(id).orElseThrow(() -> new RuntimeException("Address not found"));
    }

    public Address create(Address address) {
        return addressRepo.save(address);
    }

    public Address update(Long id, Address updated) {
        Address existing = getById(id);
        existing.setStreet(updated.getStreet());
        existing.setCity(updated.getCity());
        existing.setState(updated.getState());
        existing.setZipcode(updated.getZipcode());
        return addressRepo.save(existing);
    }

    public void delete(Long id) {
        addressRepo.deleteById(id);
    }
}