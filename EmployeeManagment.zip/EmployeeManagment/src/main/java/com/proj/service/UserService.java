package com.proj.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proj.model.User;
import com.proj.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {
	@Autowired
 UserRepository userRepo;

    public List<User> getAll() {
        return userRepo.findAll();
    }

    public User getById(Long id) {
        return userRepo.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
    }

    public User create(User user) {
        return userRepo.save(user);
    }

    public User update(Long id, User updated) {
        User existing = getById(id);
        existing.setUsername(updated.getUsername());
        existing.setPassword(updated.getPassword()); 
        existing.setEnabled(updated.isEnabled());
        existing.setRoles(updated.getRoles());
        return userRepo.save(existing);
    }

    public void delete(Long id) {
        userRepo.deleteById(id);
    }
}