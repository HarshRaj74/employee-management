package com.proj.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proj.model.Department;
import com.proj.repository.DepartmentRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DepartmentService {
	@Autowired
 DepartmentRepository departmentRepo;

    public List<Department> getAll() {
        return departmentRepo.findAll();
    }

    public Department getById(Long id) {
        return departmentRepo.findById(id).orElseThrow(() -> new RuntimeException("Department not found"));
    }

    public Department create(Department department) {
        return departmentRepo.save(department);
    }

    public Department update(Long id, Department updated) {
        Department existing = getById(id);
        existing.setName(updated.getName());
        return departmentRepo.save(existing);
    }

    public void delete(Long id) {
        departmentRepo.deleteById(id);
    }
}
