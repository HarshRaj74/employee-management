package com.proj.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.proj.model.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {


}
