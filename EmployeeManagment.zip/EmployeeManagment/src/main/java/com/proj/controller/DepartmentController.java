package com.proj.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.proj.model.Department;
import com.proj.service.DepartmentService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/departments")
@RequiredArgsConstructor
@Tag(name = "Department Controller", description = "Manage employee departments")
public class DepartmentController {

    @Autowired
    DepartmentService departmentService;

    @Operation(summary = "Get all departments", description = "Retrieve a list of all departments")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved department list")
    })
    @GetMapping
    public List<Department> getAll() {
        return departmentService.getAll();
    }

    @Operation(summary = "Get department by ID", description = "Retrieve a department by its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved department"),
            @ApiResponse(responseCode = "404", description = "Department not found")
    })
    @GetMapping("/{id}")
    public Department getById(@PathVariable Long id) {
        return departmentService.getById(id);
    }

    @Operation(summary = "Create new department", description = "Add a new department to the database")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Department successfully created")
    })
    @PostMapping
    public Department create(@RequestBody Department department) {
        return departmentService.create(department);
    }

    @Operation(summary = "Update department", description = "Update existing department details using ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Department successfully updated"),
            @ApiResponse(responseCode = "404", description = "Department not found")
    })
    @PutMapping("/{id}")
    public Department update(@PathVariable Long id, @RequestBody Department department) {
        return departmentService.update(id, department);
    }

    @Operation(summary = "Delete department", description = "Delete a department using its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Department successfully deleted"),
            @ApiResponse(responseCode = "404", description = "Department not found")
    })
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        departmentService.delete(id);
    }
}
