package com.proj.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.proj.model.Role;
import com.proj.service.RoleService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/roles")
@RequiredArgsConstructor
@Tag(name = "Role Controller", description = "Manage employee roles within the system")
public class RoleController {

    @Autowired
    RoleService roleService;

    @Operation(summary = "Get all roles", description = "Retrieve a list of all available roles")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved role list")
    })
    @GetMapping
    public List<Role> getAll() {
        return roleService.getAll();
    }

    @Operation(summary = "Get role by ID", description = "Retrieve details of a specific role using its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved role"),
            @ApiResponse(responseCode = "404", description = "Role not found")
    })
    @GetMapping("/{id}")
    public Role getById(@PathVariable Long id) {
        return roleService.getById(id);
    }

    @Operation(summary = "Create new role", description = "Add a new role to the database")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Role successfully created")
    })
    @PostMapping
    public Role create(@RequestBody Role role) {
        return roleService.create(role);
    }

    @Operation(summary = "Delete role", description = "Delete an existing role using its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Role successfully deleted"),
            @ApiResponse(responseCode = "404", description = "Role not found")
    })
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        roleService.delete(id);
    }
}
