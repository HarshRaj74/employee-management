package com.proj.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.proj.model.Address;
import com.proj.service.AddressService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/addresses")
@RequiredArgsConstructor
@Tag(name = "Address Controller", description = "Manage employee addresses")
public class AddressController {

    @Autowired
    AddressService addressService;

    @Operation(summary = "Get all addresses", description = "Retrieve a list of all addresses")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved list")
    })
    @GetMapping
    public List<Address> getAll() {
        return addressService.getAll();
    }

    @Operation(summary = "Get address by ID", description = "Retrieve a single address using its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successfully retrieved address"),
            @ApiResponse(responseCode = "404", description = "Address not found")
    })
    @GetMapping("/{id}")
    public Address getById(@PathVariable Long id) {
        return addressService.getById(id);
    }

    @Operation(summary = "Create a new address", description = "Add a new address to the database")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Address successfully created")
    })
    @PostMapping
    public Address create(@RequestBody Address address) {
        return addressService.create(address);
    }

    @Operation(summary = "Update an existing address", description = "Update address details using ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Address successfully updated"),
            @ApiResponse(responseCode = "404", description = "Address not found")
    })
    @PutMapping("/{id}")
    public Address update(@PathVariable Long id, @RequestBody Address address) {
        return addressService.update(id, address);
    }

    @Operation(summary = "Delete address by ID", description = "Remove an address from the database using its ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Address successfully deleted"),
            @ApiResponse(responseCode = "404", description = "Address not found")
    })
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        addressService.delete(id);
    }
}


